﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InteractionWithReply
{
    public class jdbc
    {
        public string Host;
        public int Port;
        public string Database;
        public string Username;
        public string Password;

        public jdbc(string all, string database)
        {
            Host = all.Split('/')[0];
            Port = Convert.ToInt32(all.Split('/')[1]);
            Username = all.Split('/')[2];
            Password = all.Split('/')[3];
            Database = database;
        }

        public string getUrl()
        {
            return Host + ':' + Port + '/' + Database;
        }
    }
}
