﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InteractionWithReply
{
    class Ontology
    {
        public string last_id { get; set; }
        public Namespaces namespaces { get; set; }
        public List<Node> nodes { get; set; }
        public List<Relation> relations { get; set; }
        public string visualize_ont_path { get; set; }
        //public Ontology(List<Node> nodes, List<Relation> relations)
        //{
        //    this.nodes = nodes;
        //    this.relations = relations;
        //}
    }

    public class Node
    {
        //public List<string> attributes { get; set; }
        public string id { get; set; }
        public string name { get; set; }
        public string _namespace { get; set; }
        public double position_x { get; set; }
        public double position_y { get; set; }
        //public Node(int id, string name, int x, int y)
        //{
        //    this.id = id.ToString();
        //    this.name = name;
        //    this.position_x = x;
        //    this.position_y = y;
        //}
    }

    public class Relation
    {
        //public List<string> attributes { get; set; }
        public string destination_node_id { get; set; }
        public string id { get; set; }
        public string name { get; set; }
        public string _namespace { get; set; }
        public string source_node_id { get; set; }
        //public Relation(int d_n_i, int id, string name, int s_n_i)
        //{
        //    destination_node_id = d_n_i.ToString();
        //    this.id = id.ToString();
        //    this.name = name;
        //    source_node_id = s_n_i.ToString();
        //}
    }

    public class Namespaces
    {
        public string _d { get; set; }
        public string ontolis { get; set; }
        public string reply_converters { get; set; }
        public string _default { get; set; }
        public string ontolis_avis { get; set; }
        public string owl { get; set; }
        public string rdf { get; set; }
        public string rdfs { get; set; }
        public string xsd { get; set; }
    }
}
