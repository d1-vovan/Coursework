﻿
namespace InteractionWithReply
{
    partial class InteractionWithReply
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tpChoiseOnt = new System.Windows.Forms.TabPage();
            this.lStringCon = new System.Windows.Forms.Label();
            this.bSaveStringCon = new System.Windows.Forms.Button();
            this.cbStringCon = new System.Windows.Forms.ComboBox();
            this.tbDirName = new System.Windows.Forms.TextBox();
            this.bChoiseDir = new System.Windows.Forms.Button();
            this.bLoadOnt = new System.Windows.Forms.Button();
            this.lReply = new System.Windows.Forms.Label();
            this.rtbComment = new System.Windows.Forms.RichTextBox();
            this.bCreateOnt = new System.Windows.Forms.Button();
            this.tpUpdate = new System.Windows.Forms.TabPage();
            this.bReplace_ = new System.Windows.Forms.Button();
            this.bDeleteNodesID = new System.Windows.Forms.Button();
            this.bDeletePrefix = new System.Windows.Forms.Button();
            this.tpTranslateV = new System.Windows.Forms.TabPage();
            this.lCross = new System.Windows.Forms.Label();
            this.lvCross = new System.Windows.Forms.ListView();
            this.NameNode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.RusDict = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.bUpdateOntTr = new System.Windows.Forms.Button();
            this.bCross = new System.Windows.Forms.Button();
            this.lDictionary = new System.Windows.Forms.Label();
            this.bLoadDictionary = new System.Windows.Forms.Button();
            this.lvDictionary = new System.Windows.Forms.ListView();
            this.Eng = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Rus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tpSinonim = new System.Windows.Forms.TabPage();
            this.bUpdateOntSin = new System.Windows.Forms.Button();
            this.nudCrossOne = new System.Windows.Forms.NumericUpDown();
            this.bCrossOneNode = new System.Windows.Forms.Button();
            this.nudNodeId = new System.Windows.Forms.NumericUpDown();
            this.lNodeId = new System.Windows.Forms.Label();
            this.bCrossAllNode = new System.Windows.Forms.Button();
            this.nudCrossAll = new System.Windows.Forms.NumericUpDown();
            this.lCrossSinonom = new System.Windows.Forms.Label();
            this.lLoadSinonim = new System.Windows.Forms.Label();
            this.bLoadSinonim = new System.Windows.Forms.Button();
            this.lvCrossSin = new System.Windows.Forms.ListView();
            this.nodeName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NodeId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.sinonimCount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.nodeSin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvSinonim = new System.Windows.Forms.ListView();
            this.Word = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.countSin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Sinonims = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tpSaveOnt = new System.Windows.Forms.TabPage();
            this.bSaveOnt = new System.Windows.Forms.Button();
            this.lvRibs = new System.Windows.Forms.ListView();
            this.destination_node_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.@__namespace = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.source_node_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvNodes = new System.Windows.Forms.ListView();
            this.id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._namespace = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.position_x = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.position_y = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lNodes = new System.Windows.Forms.Label();
            this.lRibs = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tpChoiseOnt.SuspendLayout();
            this.tpUpdate.SuspendLayout();
            this.tpTranslateV.SuspendLayout();
            this.tpSinonim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrossOne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNodeId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrossAll)).BeginInit();
            this.tpSaveOnt.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.tpChoiseOnt);
            this.tabControl.Controls.Add(this.tpUpdate);
            this.tabControl.Controls.Add(this.tpTranslateV);
            this.tabControl.Controls.Add(this.tpSinonim);
            this.tabControl.Controls.Add(this.tpSaveOnt);
            this.tabControl.Location = new System.Drawing.Point(1, 1);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(841, 372);
            this.tabControl.TabIndex = 0;
            // 
            // tpChoiseOnt
            // 
            this.tpChoiseOnt.Controls.Add(this.lStringCon);
            this.tpChoiseOnt.Controls.Add(this.bSaveStringCon);
            this.tpChoiseOnt.Controls.Add(this.cbStringCon);
            this.tpChoiseOnt.Controls.Add(this.tbDirName);
            this.tpChoiseOnt.Controls.Add(this.bChoiseDir);
            this.tpChoiseOnt.Controls.Add(this.bLoadOnt);
            this.tpChoiseOnt.Controls.Add(this.lReply);
            this.tpChoiseOnt.Controls.Add(this.rtbComment);
            this.tpChoiseOnt.Controls.Add(this.bCreateOnt);
            this.tpChoiseOnt.Location = new System.Drawing.Point(4, 25);
            this.tpChoiseOnt.Name = "tpChoiseOnt";
            this.tpChoiseOnt.Padding = new System.Windows.Forms.Padding(3);
            this.tpChoiseOnt.Size = new System.Drawing.Size(833, 343);
            this.tpChoiseOnt.TabIndex = 0;
            this.tpChoiseOnt.Text = "Выбор онтологии";
            this.tpChoiseOnt.UseVisualStyleBackColor = true;
            this.tpChoiseOnt.Resize += new System.EventHandler(this.tpChoiseOnt_Resize);
            // 
            // lStringCon
            // 
            this.lStringCon.AutoSize = true;
            this.lStringCon.Location = new System.Drawing.Point(103, 14);
            this.lStringCon.Name = "lStringCon";
            this.lStringCon.Size = new System.Drawing.Size(201, 17);
            this.lStringCon.TabIndex = 36;
            this.lStringCon.Text = "Host/Port/Username/Password";
            // 
            // bSaveStringCon
            // 
            this.bSaveStringCon.Location = new System.Drawing.Point(10, 48);
            this.bSaveStringCon.Name = "bSaveStringCon";
            this.bSaveStringCon.Size = new System.Drawing.Size(153, 30);
            this.bSaveStringCon.TabIndex = 35;
            this.bSaveStringCon.Text = "Сохранить строку подключения";
            this.bSaveStringCon.UseVisualStyleBackColor = true;
            this.bSaveStringCon.Click += new System.EventHandler(this.bSaveStringCon_Click);
            // 
            // cbStringCon
            // 
            this.cbStringCon.FormattingEnabled = true;
            this.cbStringCon.Location = new System.Drawing.Point(183, 54);
            this.cbStringCon.Name = "cbStringCon";
            this.cbStringCon.Size = new System.Drawing.Size(223, 24);
            this.cbStringCon.TabIndex = 34;
            // 
            // tbDirName
            // 
            this.tbDirName.Location = new System.Drawing.Point(183, 108);
            this.tbDirName.Name = "tbDirName";
            this.tbDirName.Size = new System.Drawing.Size(223, 22);
            this.tbDirName.TabIndex = 30;
            // 
            // bChoiseDir
            // 
            this.bChoiseDir.Location = new System.Drawing.Point(10, 100);
            this.bChoiseDir.Name = "bChoiseDir";
            this.bChoiseDir.Size = new System.Drawing.Size(153, 30);
            this.bChoiseDir.TabIndex = 29;
            this.bChoiseDir.Text = "Выбор директории";
            this.bChoiseDir.UseVisualStyleBackColor = true;
            this.bChoiseDir.Click += new System.EventHandler(this.choiseDir_Click);
            // 
            // bLoadOnt
            // 
            this.bLoadOnt.Location = new System.Drawing.Point(412, 155);
            this.bLoadOnt.Name = "bLoadOnt";
            this.bLoadOnt.Size = new System.Drawing.Size(401, 40);
            this.bLoadOnt.TabIndex = 28;
            this.bLoadOnt.Text = "Загрузить существующую онтологию";
            this.bLoadOnt.UseVisualStyleBackColor = true;
            this.bLoadOnt.Click += new System.EventHandler(this.bLoadOnt_Click);
            // 
            // lReply
            // 
            this.lReply.AutoSize = true;
            this.lReply.Location = new System.Drawing.Point(7, 218);
            this.lReply.Name = "lReply";
            this.lReply.Size = new System.Drawing.Size(206, 17);
            this.lReply.TabIndex = 27;
            this.lReply.Text = "Процесс создания онтологии:";
            // 
            // rtbComment
            // 
            this.rtbComment.Location = new System.Drawing.Point(10, 238);
            this.rtbComment.Name = "rtbComment";
            this.rtbComment.Size = new System.Drawing.Size(806, 76);
            this.rtbComment.TabIndex = 26;
            this.rtbComment.Text = "";
            // 
            // bCreateOnt
            // 
            this.bCreateOnt.Enabled = false;
            this.bCreateOnt.Location = new System.Drawing.Point(10, 155);
            this.bCreateOnt.Name = "bCreateOnt";
            this.bCreateOnt.Size = new System.Drawing.Size(396, 40);
            this.bCreateOnt.TabIndex = 24;
            this.bCreateOnt.Text = "Создать онтологию из БД под выбранной директорией";
            this.bCreateOnt.UseVisualStyleBackColor = true;
            this.bCreateOnt.Click += new System.EventHandler(this.bCreateOnt_Click);
            // 
            // tpUpdate
            // 
            this.tpUpdate.Controls.Add(this.bReplace_);
            this.tpUpdate.Controls.Add(this.bDeleteNodesID);
            this.tpUpdate.Controls.Add(this.bDeletePrefix);
            this.tpUpdate.Location = new System.Drawing.Point(4, 25);
            this.tpUpdate.Name = "tpUpdate";
            this.tpUpdate.Size = new System.Drawing.Size(833, 343);
            this.tpUpdate.TabIndex = 2;
            this.tpUpdate.Text = "Изменение онтологии";
            this.tpUpdate.UseVisualStyleBackColor = true;
            // 
            // bReplace_
            // 
            this.bReplace_.Location = new System.Drawing.Point(82, 215);
            this.bReplace_.Name = "bReplace_";
            this.bReplace_.Size = new System.Drawing.Size(324, 45);
            this.bReplace_.TabIndex = 6;
            this.bReplace_.Text = "Заменить все \"_\" на \" \"";
            this.bReplace_.UseVisualStyleBackColor = true;
            this.bReplace_.Click += new System.EventHandler(this.bReplace__Click);
            // 
            // bDeleteNodesID
            // 
            this.bDeleteNodesID.Location = new System.Drawing.Point(412, 145);
            this.bDeleteNodesID.Name = "bDeleteNodesID";
            this.bDeleteNodesID.Size = new System.Drawing.Size(324, 45);
            this.bDeleteNodesID.TabIndex = 5;
            this.bDeleteNodesID.Text = "Удалить вершины и их связи, начинающиеся, или заканчивающиеся на id";
            this.bDeleteNodesID.UseVisualStyleBackColor = true;
            this.bDeleteNodesID.Click += new System.EventHandler(this.bDeleteNodesID_Click);
            // 
            // bDeletePrefix
            // 
            this.bDeletePrefix.Location = new System.Drawing.Point(82, 145);
            this.bDeletePrefix.Name = "bDeletePrefix";
            this.bDeletePrefix.Size = new System.Drawing.Size(324, 45);
            this.bDeletePrefix.TabIndex = 4;
            this.bDeletePrefix.Text = "Удалить у вершин префиксы (к какой таблице принадлежат и тд)";
            this.bDeletePrefix.UseVisualStyleBackColor = true;
            this.bDeletePrefix.Click += new System.EventHandler(this.bDeletePrefix_Click);
            // 
            // tpTranslateV
            // 
            this.tpTranslateV.Controls.Add(this.lCross);
            this.tpTranslateV.Controls.Add(this.lvCross);
            this.tpTranslateV.Controls.Add(this.bUpdateOntTr);
            this.tpTranslateV.Controls.Add(this.bCross);
            this.tpTranslateV.Controls.Add(this.lDictionary);
            this.tpTranslateV.Controls.Add(this.bLoadDictionary);
            this.tpTranslateV.Controls.Add(this.lvDictionary);
            this.tpTranslateV.Location = new System.Drawing.Point(4, 25);
            this.tpTranslateV.Name = "tpTranslateV";
            this.tpTranslateV.Padding = new System.Windows.Forms.Padding(3);
            this.tpTranslateV.Size = new System.Drawing.Size(833, 343);
            this.tpTranslateV.TabIndex = 1;
            this.tpTranslateV.Text = "Перевод вершин";
            this.tpTranslateV.UseVisualStyleBackColor = true;
            this.tpTranslateV.Resize += new System.EventHandler(this.tpTranslateV_Resize);
            // 
            // lCross
            // 
            this.lCross.AutoSize = true;
            this.lCross.Location = new System.Drawing.Point(335, 78);
            this.lCross.Name = "lCross";
            this.lCross.Size = new System.Drawing.Size(101, 17);
            this.lCross.TabIndex = 9;
            this.lCross.Text = "Пересечение:";
            // 
            // lvCross
            // 
            this.lvCross.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.NameNode,
            this.RusDict});
            this.lvCross.HideSelection = false;
            this.lvCross.Location = new System.Drawing.Point(328, 98);
            this.lvCross.Name = "lvCross";
            this.lvCross.Size = new System.Drawing.Size(502, 223);
            this.lvCross.TabIndex = 8;
            this.lvCross.UseCompatibleStateImageBehavior = false;
            this.lvCross.View = System.Windows.Forms.View.Details;
            // 
            // NameNode
            // 
            this.NameNode.Text = "Имя вершины";
            // 
            // RusDict
            // 
            this.RusDict.Text = "Перевод из словаря";
            // 
            // bUpdateOntTr
            // 
            this.bUpdateOntTr.Location = new System.Drawing.Point(554, 20);
            this.bUpdateOntTr.Name = "bUpdateOntTr";
            this.bUpdateOntTr.Size = new System.Drawing.Size(244, 45);
            this.bUpdateOntTr.TabIndex = 7;
            this.bUpdateOntTr.Text = "Приписать к каждой найденной вершине русский перевод";
            this.bUpdateOntTr.UseVisualStyleBackColor = true;
            this.bUpdateOntTr.Click += new System.EventHandler(this.bUpdateOntTr_Click);
            // 
            // bCross
            // 
            this.bCross.Location = new System.Drawing.Point(282, 20);
            this.bCross.Name = "bCross";
            this.bCross.Size = new System.Drawing.Size(244, 45);
            this.bCross.TabIndex = 6;
            this.bCross.Text = "Пересечь словарь и названия вершин";
            this.bCross.UseVisualStyleBackColor = true;
            this.bCross.Click += new System.EventHandler(this.bCross_Click);
            // 
            // lDictionary
            // 
            this.lDictionary.AutoSize = true;
            this.lDictionary.Location = new System.Drawing.Point(7, 78);
            this.lDictionary.Name = "lDictionary";
            this.lDictionary.Size = new System.Drawing.Size(67, 17);
            this.lDictionary.TabIndex = 2;
            this.lDictionary.Text = "Словарь:";
            // 
            // bLoadDictionary
            // 
            this.bLoadDictionary.Location = new System.Drawing.Point(21, 20);
            this.bLoadDictionary.Name = "bLoadDictionary";
            this.bLoadDictionary.Size = new System.Drawing.Size(237, 45);
            this.bLoadDictionary.TabIndex = 1;
            this.bLoadDictionary.Text = "Загрузить англо-русский словарь";
            this.bLoadDictionary.UseVisualStyleBackColor = true;
            this.bLoadDictionary.Click += new System.EventHandler(this.bLoadDictionary_Click);
            // 
            // lvDictionary
            // 
            this.lvDictionary.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Eng,
            this.Rus});
            this.lvDictionary.HideSelection = false;
            this.lvDictionary.Location = new System.Drawing.Point(0, 98);
            this.lvDictionary.Name = "lvDictionary";
            this.lvDictionary.Size = new System.Drawing.Size(302, 223);
            this.lvDictionary.TabIndex = 0;
            this.lvDictionary.UseCompatibleStateImageBehavior = false;
            this.lvDictionary.View = System.Windows.Forms.View.Details;
            // 
            // Eng
            // 
            this.Eng.Text = "Английский";
            // 
            // Rus
            // 
            this.Rus.Text = "Русский";
            // 
            // tpSinonim
            // 
            this.tpSinonim.Controls.Add(this.bUpdateOntSin);
            this.tpSinonim.Controls.Add(this.nudCrossOne);
            this.tpSinonim.Controls.Add(this.bCrossOneNode);
            this.tpSinonim.Controls.Add(this.nudNodeId);
            this.tpSinonim.Controls.Add(this.lNodeId);
            this.tpSinonim.Controls.Add(this.bCrossAllNode);
            this.tpSinonim.Controls.Add(this.nudCrossAll);
            this.tpSinonim.Controls.Add(this.lCrossSinonom);
            this.tpSinonim.Controls.Add(this.lLoadSinonim);
            this.tpSinonim.Controls.Add(this.bLoadSinonim);
            this.tpSinonim.Controls.Add(this.lvCrossSin);
            this.tpSinonim.Controls.Add(this.lvSinonim);
            this.tpSinonim.Location = new System.Drawing.Point(4, 25);
            this.tpSinonim.Name = "tpSinonim";
            this.tpSinonim.Size = new System.Drawing.Size(833, 343);
            this.tpSinonim.TabIndex = 3;
            this.tpSinonim.Text = "Синонимы вершин";
            this.tpSinonim.UseVisualStyleBackColor = true;
            this.tpSinonim.Resize += new System.EventHandler(this.tpSinonim_Resize);
            // 
            // bUpdateOntSin
            // 
            this.bUpdateOntSin.Location = new System.Drawing.Point(315, 88);
            this.bUpdateOntSin.Name = "bUpdateOntSin";
            this.bUpdateOntSin.Size = new System.Drawing.Size(498, 33);
            this.bUpdateOntSin.TabIndex = 11;
            this.bUpdateOntSin.Text = "Приписать к каждой переведённой вершине синоним";
            this.bUpdateOntSin.UseVisualStyleBackColor = true;
            this.bUpdateOntSin.Click += new System.EventHandler(this.bUpdateOntSin_Click);
            // 
            // nudCrossOne
            // 
            this.nudCrossOne.Location = new System.Drawing.Point(736, 59);
            this.nudCrossOne.Name = "nudCrossOne";
            this.nudCrossOne.Size = new System.Drawing.Size(77, 22);
            this.nudCrossOne.TabIndex = 10;
            // 
            // bCrossOneNode
            // 
            this.bCrossOneNode.Location = new System.Drawing.Point(519, 47);
            this.bCrossOneNode.Name = "bCrossOneNode";
            this.bCrossOneNode.Size = new System.Drawing.Size(201, 34);
            this.bCrossOneNode.TabIndex = 9;
            this.bCrossOneNode.Text = "пересечь с n синонимами";
            this.bCrossOneNode.UseVisualStyleBackColor = true;
            this.bCrossOneNode.Click += new System.EventHandler(this.bCrossOneNode_Click);
            // 
            // nudNodeId
            // 
            this.nudNodeId.Location = new System.Drawing.Point(427, 56);
            this.nudNodeId.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nudNodeId.Name = "nudNodeId";
            this.nudNodeId.Size = new System.Drawing.Size(74, 22);
            this.nudNodeId.TabIndex = 8;
            // 
            // lNodeId
            // 
            this.lNodeId.AutoSize = true;
            this.lNodeId.Location = new System.Drawing.Point(312, 58);
            this.lNodeId.Name = "lNodeId";
            this.lNodeId.Size = new System.Drawing.Size(105, 17);
            this.lNodeId.TabIndex = 7;
            this.lNodeId.Text = "Вершину с id =";
            // 
            // bCrossAllNode
            // 
            this.bCrossAllNode.Location = new System.Drawing.Point(315, 9);
            this.bCrossAllNode.Name = "bCrossAllNode";
            this.bCrossAllNode.Size = new System.Drawing.Size(414, 32);
            this.bCrossAllNode.TabIndex = 6;
            this.bCrossAllNode.Text = "Каждую переведённую вершину пересечь с n синонимами";
            this.bCrossAllNode.UseVisualStyleBackColor = true;
            this.bCrossAllNode.Click += new System.EventHandler(this.bCrossAllNode_Click);
            // 
            // nudCrossAll
            // 
            this.nudCrossAll.Location = new System.Drawing.Point(735, 19);
            this.nudCrossAll.Name = "nudCrossAll";
            this.nudCrossAll.Size = new System.Drawing.Size(78, 22);
            this.nudCrossAll.TabIndex = 5;
            // 
            // lCrossSinonom
            // 
            this.lCrossSinonom.AutoSize = true;
            this.lCrossSinonom.Location = new System.Drawing.Point(312, 135);
            this.lCrossSinonom.Name = "lCrossSinonom";
            this.lCrossSinonom.Size = new System.Drawing.Size(239, 17);
            this.lCrossSinonom.TabIndex = 4;
            this.lCrossSinonom.Text = "Пересечённая таблица синонимов";
            // 
            // lLoadSinonim
            // 
            this.lLoadSinonim.AutoSize = true;
            this.lLoadSinonim.Location = new System.Drawing.Point(7, 135);
            this.lLoadSinonim.Name = "lLoadSinonim";
            this.lLoadSinonim.Size = new System.Drawing.Size(142, 17);
            this.lLoadSinonim.TabIndex = 3;
            this.lLoadSinonim.Text = "Словарь синонимов:";
            // 
            // bLoadSinonim
            // 
            this.bLoadSinonim.Location = new System.Drawing.Point(27, 76);
            this.bLoadSinonim.Name = "bLoadSinonim";
            this.bLoadSinonim.Size = new System.Drawing.Size(237, 45);
            this.bLoadSinonim.TabIndex = 2;
            this.bLoadSinonim.Text = "Загрузить словарь синонимов";
            this.bLoadSinonim.UseVisualStyleBackColor = true;
            this.bLoadSinonim.Click += new System.EventHandler(this.bLoadSinonim_Click);
            // 
            // lvCrossSin
            // 
            this.lvCrossSin.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.nodeName,
            this.NodeId,
            this.sinonimCount,
            this.nodeSin});
            this.lvCrossSin.HideSelection = false;
            this.lvCrossSin.Location = new System.Drawing.Point(315, 166);
            this.lvCrossSin.Name = "lvCrossSin";
            this.lvCrossSin.Size = new System.Drawing.Size(518, 157);
            this.lvCrossSin.TabIndex = 1;
            this.lvCrossSin.UseCompatibleStateImageBehavior = false;
            this.lvCrossSin.View = System.Windows.Forms.View.Details;
            // 
            // nodeName
            // 
            this.nodeName.Text = "Имя вершины";
            // 
            // NodeId
            // 
            this.NodeId.Text = "id";
            // 
            // sinonimCount
            // 
            this.sinonimCount.Text = "Кол-во пересеч. син.";
            // 
            // nodeSin
            // 
            this.nodeSin.Text = "Синонимы";
            // 
            // lvSinonim
            // 
            this.lvSinonim.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Word,
            this.countSin,
            this.Sinonims});
            this.lvSinonim.HideSelection = false;
            this.lvSinonim.Location = new System.Drawing.Point(7, 166);
            this.lvSinonim.Name = "lvSinonim";
            this.lvSinonim.Size = new System.Drawing.Size(281, 157);
            this.lvSinonim.TabIndex = 0;
            this.lvSinonim.UseCompatibleStateImageBehavior = false;
            this.lvSinonim.View = System.Windows.Forms.View.Details;
            // 
            // Word
            // 
            this.Word.Text = "Слово";
            // 
            // countSin
            // 
            this.countSin.Text = "Количество синонимов";
            // 
            // Sinonims
            // 
            this.Sinonims.Text = "Синонимы";
            // 
            // tpSaveOnt
            // 
            this.tpSaveOnt.Controls.Add(this.bSaveOnt);
            this.tpSaveOnt.Location = new System.Drawing.Point(4, 25);
            this.tpSaveOnt.Name = "tpSaveOnt";
            this.tpSaveOnt.Size = new System.Drawing.Size(833, 343);
            this.tpSaveOnt.TabIndex = 4;
            this.tpSaveOnt.Text = "Сохранение онтологии";
            this.tpSaveOnt.UseVisualStyleBackColor = true;
            // 
            // bSaveOnt
            // 
            this.bSaveOnt.Location = new System.Drawing.Point(303, 114);
            this.bSaveOnt.Name = "bSaveOnt";
            this.bSaveOnt.Size = new System.Drawing.Size(212, 64);
            this.bSaveOnt.TabIndex = 0;
            this.bSaveOnt.Text = "Сохранить текущую онтологию";
            this.bSaveOnt.UseVisualStyleBackColor = true;
            this.bSaveOnt.Click += new System.EventHandler(this.bSaveOnt_Click);
            // 
            // lvRibs
            // 
            this.lvRibs.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lvRibs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.destination_node_id,
            this._id,
            this._name,
            this.@__namespace,
            this.source_node_id});
            this.lvRibs.HideSelection = false;
            this.lvRibs.Location = new System.Drawing.Point(417, 401);
            this.lvRibs.Name = "lvRibs";
            this.lvRibs.Size = new System.Drawing.Size(425, 155);
            this.lvRibs.TabIndex = 16;
            this.lvRibs.UseCompatibleStateImageBehavior = false;
            this.lvRibs.View = System.Windows.Forms.View.Details;
            // 
            // destination_node_id
            // 
            this.destination_node_id.Text = "Куда";
            // 
            // _id
            // 
            this._id.Text = "id";
            // 
            // _name
            // 
            this._name.Text = "Имя";
            // 
            // __namespace
            // 
            this.@__namespace.Text = "namespace";
            // 
            // source_node_id
            // 
            this.source_node_id.Text = "Откуда";
            // 
            // lvNodes
            // 
            this.lvNodes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lvNodes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.id,
            this.name,
            this._namespace,
            this.position_x,
            this.position_y});
            this.lvNodes.HideSelection = false;
            this.lvNodes.Location = new System.Drawing.Point(1, 401);
            this.lvNodes.Name = "lvNodes";
            this.lvNodes.Size = new System.Drawing.Size(410, 155);
            this.lvNodes.TabIndex = 15;
            this.lvNodes.UseCompatibleStateImageBehavior = false;
            this.lvNodes.View = System.Windows.Forms.View.Details;
            // 
            // id
            // 
            this.id.Text = "id";
            // 
            // name
            // 
            this.name.Text = "Имя";
            // 
            // _namespace
            // 
            this._namespace.Text = "namespace";
            // 
            // position_x
            // 
            this.position_x.Text = "Коорд. Х";
            // 
            // position_y
            // 
            this.position_y.Text = "Коорд. Y";
            // 
            // lNodes
            // 
            this.lNodes.AutoSize = true;
            this.lNodes.Location = new System.Drawing.Point(2, 376);
            this.lNodes.Name = "lNodes";
            this.lNodes.Size = new System.Drawing.Size(119, 17);
            this.lNodes.TabIndex = 17;
            this.lNodes.Text = "Таблица вершин";
            // 
            // lRibs
            // 
            this.lRibs.AutoSize = true;
            this.lRibs.Location = new System.Drawing.Point(414, 376);
            this.lRibs.Name = "lRibs";
            this.lRibs.Size = new System.Drawing.Size(114, 17);
            this.lRibs.TabIndex = 18;
            this.lRibs.Text = "Таблица связей";
            // 
            // InteractionWithReply
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(830, 547);
            this.Controls.Add(this.lRibs);
            this.Controls.Add(this.lNodes);
            this.Controls.Add(this.lvRibs);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.lvNodes);
            this.Name = "InteractionWithReply";
            this.Text = "InteractonWithReply";
            this.Resize += new System.EventHandler(this.InteractionWithReply_Resize);
            this.tabControl.ResumeLayout(false);
            this.tpChoiseOnt.ResumeLayout(false);
            this.tpChoiseOnt.PerformLayout();
            this.tpUpdate.ResumeLayout(false);
            this.tpTranslateV.ResumeLayout(false);
            this.tpTranslateV.PerformLayout();
            this.tpSinonim.ResumeLayout(false);
            this.tpSinonim.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrossOne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNodeId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrossAll)).EndInit();
            this.tpSaveOnt.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tpChoiseOnt;
        private System.Windows.Forms.TabPage tpTranslateV;
        private System.Windows.Forms.RichTextBox rtbComment;
        private System.Windows.Forms.Button bCreateOnt;
        private System.Windows.Forms.ListView lvRibs;
        private System.Windows.Forms.ColumnHeader destination_node_id;
        private System.Windows.Forms.ColumnHeader _id;
        private System.Windows.Forms.ColumnHeader _name;
        private System.Windows.Forms.ColumnHeader __namespace;
        private System.Windows.Forms.ColumnHeader source_node_id;
        private System.Windows.Forms.ListView lvNodes;
        private System.Windows.Forms.ColumnHeader id;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.ColumnHeader _namespace;
        private System.Windows.Forms.ColumnHeader position_x;
        private System.Windows.Forms.ColumnHeader position_y;
        private System.Windows.Forms.Button bLoadOnt;
        private System.Windows.Forms.Label lReply;
        private System.Windows.Forms.TabPage tpUpdate;
        private System.Windows.Forms.Button bDeletePrefix;
        private System.Windows.Forms.Label lCross;
        private System.Windows.Forms.ListView lvCross;
        private System.Windows.Forms.ColumnHeader NameNode;
        private System.Windows.Forms.ColumnHeader RusDict;
        private System.Windows.Forms.Button bUpdateOntTr;
        private System.Windows.Forms.Button bCross;
        private System.Windows.Forms.Label lDictionary;
        private System.Windows.Forms.Button bLoadDictionary;
        private System.Windows.Forms.ListView lvDictionary;
        private System.Windows.Forms.ColumnHeader Eng;
        private System.Windows.Forms.ColumnHeader Rus;
        private System.Windows.Forms.TabPage tpSinonim;
        private System.Windows.Forms.NumericUpDown nudCrossOne;
        private System.Windows.Forms.Button bCrossOneNode;
        private System.Windows.Forms.NumericUpDown nudNodeId;
        private System.Windows.Forms.Label lNodeId;
        private System.Windows.Forms.Button bCrossAllNode;
        private System.Windows.Forms.NumericUpDown nudCrossAll;
        private System.Windows.Forms.Label lCrossSinonom;
        private System.Windows.Forms.Label lLoadSinonim;
        private System.Windows.Forms.Button bLoadSinonim;
        private System.Windows.Forms.ListView lvCrossSin;
        private System.Windows.Forms.ListView lvSinonim;
        private System.Windows.Forms.ColumnHeader Word;
        private System.Windows.Forms.ColumnHeader countSin;
        private System.Windows.Forms.ColumnHeader Sinonims;
        private System.Windows.Forms.ColumnHeader nodeName;
        private System.Windows.Forms.ColumnHeader sinonimCount;
        private System.Windows.Forms.ColumnHeader nodeSin;
        private System.Windows.Forms.ColumnHeader NodeId;
        private System.Windows.Forms.Button bUpdateOntSin;
        private System.Windows.Forms.TabPage tpSaveOnt;
        private System.Windows.Forms.Button bSaveOnt;
        private System.Windows.Forms.TextBox tbDirName;
        private System.Windows.Forms.Button bChoiseDir;
        private System.Windows.Forms.Button bSaveStringCon;
        private System.Windows.Forms.ComboBox cbStringCon;
        private System.Windows.Forms.Label lStringCon;
        private System.Windows.Forms.Label lNodes;
        private System.Windows.Forms.Label lRibs;
        private System.Windows.Forms.Button bDeleteNodesID;
        private System.Windows.Forms.Button bReplace_;
    }
}

