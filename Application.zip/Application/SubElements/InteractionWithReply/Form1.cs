﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InteractionWithReply
{
    public partial class InteractionWithReply : Form
    {
        public int indexOnt = 0;

        public void LoadStringCon()
        {
            StreamReader cout = new StreamReader("config.txt");
            string temp;
            while((temp = cout.ReadLine()) != null)
                cbStringCon.Items.Add(temp);
        }

        public void DeleteCurrOnt()
        {
            string x = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(Application.StartupPath))) + "\\curProjects";
            DirectoryInfo dirInfo = new DirectoryInfo(x);

            foreach (FileInfo file in dirInfo.GetFiles())
                file.Delete();
        }

        public InteractionWithReply()
        {
            InitializeComponent();
            DeleteCurrOnt();
            LoadStringCon();
            InteractionWithReply_Resize(new object(), new EventArgs());
        }

        private void bCreateOnt_Click(object sender, EventArgs e)
        {
            jdbc Con;
            string sConnStr = "", nameBD = "";
            try
            {
                Con = new jdbc(cbStringCon.Text, "template1");
                sConnStr = new NpgsqlConnectionStringBuilder
                {
                    Host = Con.Host,
                    Port = Con.Port,
                    Database = Con.Database,
                    Username = Con.Username,
                    Password = Con.Password
                }.ConnectionString;
            }
            catch
            {
                MessageBox.Show("Неудалось подключиться к бд. Поменяйте строку подключения", "Ошибка при подключении к бд");
                return;
            }
            try
            {
                using (var sConn = new NpgsqlConnection(sConnStr))
                {
                    sConn.Open();
                    var sCommand = new NpgsqlCommand
                    {
                        Connection = sConn,
                        CommandText = @"SELECT datname from pg_database WHERE oid = @Myoid;"
                    };

                    sCommand.Parameters.AddWithValue("@Myoid", Convert.ToInt32(tbDirName.Text.Split('\\')[tbDirName.Text.Split('\\').Length-1]));
                    nameBD = (string)sCommand.ExecuteScalar();
                }
            }
            catch
            {
                MessageBox.Show("Ошибка при выборе схемы бд. Поменяйте путь к схеме бд", "Ошибка при подключении к бд");
                return;
            }
            DialogResult dialogResult = MessageBox.Show("Вы действительно хотите сделать из бд \"" + nameBD + "\" онтологию?", 
                "На пути к онтологии", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.No)
                return;

            Con = new jdbc(cbStringCon.Text, nameBD);
            string directory = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(Application.StartupPath)));
            string x = directory + @"\Reply\reply-obda-bootstrap-cli\bin\reply-obda-bootstrap-cli --jdbc-url jdbc:postgresql://" + Con.getUrl() + 
                " --jdbc-username " + Con.Username + " --jdbc-password " + Con.Password + @" --ontology-iri-prefix http://movs.psu.ru/~ipostanogov/ --out-base-name " +
                indexOnt + @" --output-directory " + directory + "\\curProjects";
            Process proc = Process.Start(new ProcessStartInfo
            {
                FileName = "cmd",
                Arguments = "/c " + x,
                UseShellExecute = false, //Отключаем любой инферфейс у процесса, чтобы небыло никаких окон
                CreateNoWindow = true, //отключаем также отображение на панеле задач
                RedirectStandardOutput = true
            });
            x = proc.StandardOutput.ReadToEnd();
            if (x.Length < 200)
                rtbComment.Text = "Ошибка при создании онтологии из БД.";
            else
                rtbComment.Text = x;

            // Перенос всего в нижные панели с вершинами и отношениями
            LoadOnt(directory + "\\curProjects\\" + indexOnt + ".ont");
            indexOnt++;
        }

        public void LoadOnt(string fileName)
        {
            string jsonString = File.ReadAllText(fileName);
            // Удалить атрибуты из файла, удалить namespace из файла
            jsonString = jsonString.Replace("namespace", "_namespace");
            jsonString = jsonString.Replace("reply-converters", "reply_converters");
            jsonString = jsonString.Replace("default", "_default");
            jsonString = jsonString.Replace("ontolis-avis", "ontolis_avis");
            jsonString = jsonString.Replace("\"\"", "\"_d\"");
            jsonString = jsonString.Replace("[ {", "[\r\n  {");
            jsonString = jsonString.Replace("}, {", "},\r\n  {");
            //jsonString = jsonString.Replace(" :", ":");
            string temp = "\"attributes\": {\r\n            },\r\n            ";
            if (jsonString.Contains(temp))
                jsonString = jsonString.Replace(temp, "");
            else
                jsonString = jsonString.Replace("\"attributes\" : { },\r\n    ", "");

            Ontology ontologyJSON = JsonSerializer.Deserialize<Ontology>(jsonString);
            lvNodes.Items.Clear();
            lvRibs.Items.Clear();
            for (int i = 0; i < ontologyJSON.nodes.Count; i++)
            {
                ListViewItem item = new ListViewItem(ontologyJSON.nodes[i].id);
                item.SubItems.Add(ontologyJSON.nodes[i].name);
                item.SubItems.Add(ontologyJSON.nodes[i]._namespace);
                item.SubItems.Add(Convert.ToInt32(ontologyJSON.nodes[i].position_x).ToString());
                item.SubItems.Add(Convert.ToInt32(ontologyJSON.nodes[i].position_y).ToString());
                lvNodes.Items.Add(item);
            }
            for (int i = 0; i < ontologyJSON.relations.Count; i++)
            {
                ListViewItem item = new ListViewItem(ontologyJSON.relations[i].destination_node_id);
                item.SubItems.Add(ontologyJSON.relations[i].id);
                item.SubItems.Add(ontologyJSON.relations[i].name);
                item.SubItems.Add(ontologyJSON.relations[i]._namespace);
                item.SubItems.Add(ontologyJSON.relations[i].source_node_id);
                lvRibs.Items.Add(item);
            }
        }

        private void bLoadOnt_Click(object sender, EventArgs e)
        {
            string fileName;
            using (OpenFileDialog openDialog = new OpenFileDialog())
            {
                openDialog.Filter = "|*.ont";
                if (openDialog.ShowDialog(this) != DialogResult.OK)
                    return;

                fileName = openDialog.FileName;
            }
            LoadOnt(fileName);
        }

        //Придётся переделать
        private void bLoadDictionary_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openDialog = new OpenFileDialog())
            {
                openDialog.Filter = "|*.txt";
                if (openDialog.ShowDialog(this) != DialogResult.OK)
                    return;

                StreamReader read = new StreamReader(openDialog.FileName);
                string line;
                while ((line = read.ReadLine()) != null)
                {
                    ListViewItem item = new ListViewItem(line.Split('/')[0]);
                    item.SubItems.Add(line.Split('/')[1]);
                    lvDictionary.Items.Add(item);
                }
            }
        }

        private void bCross_Click(object sender, EventArgs e)
        {
            lvCross.Items.Clear();
            for (int i = 0; i < lvNodes.Items.Count; i++)
            {
                bool use = false;
                for (int j = 0; j < lvDictionary.Items.Count && !use; j++)
                    if (lvNodes.Items[i].SubItems[1].Text == lvDictionary.Items[j].SubItems[0].Text)
                    {
                        ListViewItem item = new ListViewItem(lvDictionary.Items[j].SubItems[0].Text);
                        item.SubItems.Add(lvDictionary.Items[j].SubItems[1].Text);
                        lvCross.Items.Add(item);
                        use = true;
                    }
                if (!use)
                {
                    ListViewItem item = new ListViewItem(lvNodes.Items[i].SubItems[1].Text);
                    item.SubItems.Add("              ");
                    lvCross.Items.Add(item);
                }
            }
        }

        private void bDeletePrefix_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lvNodes.Items.Count; i++)
            {
                string temp = lvNodes.Items[i].SubItems[1].Text;
                temp = temp.Remove(0, temp.LastIndexOf('.') + 1);
                lvNodes.Items[i].SubItems[1].Text = temp;
            }
        }

        private void bUpdateOntTr_Click(object sender, EventArgs e)
        {
            int maxIndex = 0;
            for (int i = 0; i < lvNodes.Items.Count; i++)
                if (Convert.ToInt32(lvNodes.Items[i].SubItems[0].Text) > maxIndex)
                    maxIndex = Convert.ToInt32(lvNodes.Items[i].SubItems[0].Text);
            for (int i = 0; i < lvRibs.Items.Count; i++)
                if (Convert.ToInt32(lvRibs.Items[i].SubItems[1].Text) > maxIndex)
                    maxIndex = Convert.ToInt32(lvRibs.Items[i].SubItems[1].Text);
            maxIndex++;

            // Добавляем вершины и отношения
            for (int i = 0; i < lvCross.Items.Count; i++)
            {
                string temp = lvCross.Items[i].SubItems[1].Text.Replace(" ", "");
                if (temp != "")
                {
                    ListViewItem item = new ListViewItem(maxIndex.ToString());
                    item.SubItems.Add(lvCross.Items[i].SubItems[1].Text);
                    item.SubItems.Add("");
                    item.SubItems.Add("0");
                    item.SubItems.Add("0");
                    lvNodes.Items.Add(item);

                    ListViewItem item2 = new ListViewItem(lvNodes.Items[i].SubItems[0].Text);
                    item2.SubItems.Add((maxIndex + 1).ToString());
                    item2.SubItems.Add("rus");
                    item2.SubItems.Add("");
                    item2.SubItems.Add(maxIndex.ToString());
                    lvRibs.Items.Add(item2);

                    maxIndex += 2;
                }
            } 
        }

        //Придётся переделать
        private void bLoadSinonim_Click(object sender, EventArgs e)
        {
            lvSinonim.Items.Clear();
            using (OpenFileDialog openDialog = new OpenFileDialog())
            {
                openDialog.Filter = "|*.txt";
                if (openDialog.ShowDialog(this) != DialogResult.OK)
                    return;

                StreamReader read = new StreamReader(openDialog.FileName);
                string line;
                while ((line = read.ReadLine()) != null)
                {
                    int count = 0;
                    for (int i = 0; i < line.Length; i++)
                        if (line[i] == '/')
                            count++;
                    
                    ListViewItem item = new ListViewItem(line.Split('/')[0]);
                    item.SubItems.Add(count.ToString());
                    item.SubItems.Add(line.Replace(line.Split('/')[0] + "/", "").Replace("/", ", "));
                    lvSinonim.Items.Add(item);
                }
            }
        }

        private void bCrossAllNode_Click(object sender, EventArgs e)
        {
            lvCrossSin.Items.Clear();
            // Находим все вершины, которые являются переводом
            List<string> names = new List<string>();
            List<string> ids = new List<string>();
            for (int i = 0; i < lvRibs.Items.Count; i++)
                if (lvRibs.Items[i].SubItems[2].Text == "rus")
                {
                    bool use = false;
                    for (int j = 0; j < lvNodes.Items.Count && !use; j++)
                        if (lvRibs.Items[i].SubItems[4].Text == lvNodes.Items[j].SubItems[0].Text)
                        {
                            names.Add(lvNodes.Items[j].SubItems[1].Text);
                            ids.Add(lvNodes.Items[j].SubItems[0].Text);
                            use = true;
                        }
                }

            for (int i = 0; i < names.Count; i++)
                for (int j = 0; j < lvSinonim.Items.Count; j++)
                    if (names[i] == lvSinonim.Items[j].SubItems[0].Text)
                    {
                        ListViewItem item = new ListViewItem(names[i]);
                        item.SubItems.Add(ids[i]);
                        if (nudCrossAll.Value > Convert.ToInt32(lvSinonim.Items[j].SubItems[1].Text))
                        {
                            item.SubItems.Add(lvSinonim.Items[j].SubItems[1].Text);
                            item.SubItems.Add(lvSinonim.Items[j].SubItems[2].Text);
                        }
                        else
                        {
                            item.SubItems.Add(nudCrossAll.Value.ToString());
                            // ПОТЕНЦИАЛЬНО ОПАСНОЕ МЕСТО!!!!!!!! БОЙСЯ!!!!!
                            string sinonims = "";
                            for (int k = 0; k < nudCrossAll.Value; k++)
                                if (k != nudCrossAll.Value - 1)
                                    sinonims += lvSinonim.Items[j].SubItems[2].Text.Split(',')[k].Trim() + ", ";
                                else
                                    sinonims += lvSinonim.Items[j].SubItems[2].Text.Split(',')[k].Trim();
                            item.SubItems.Add(sinonims);
                        }
                            
                        lvCrossSin.Items.Add(item);
                    }
        }

        private void bCrossOneNode_Click(object sender, EventArgs e)
        {
            // Находим ту самую вершину
            string name = "";
            bool use = false;
            for (int i = 0; i < lvNodes.Items.Count && !use; i++)
                if (lvNodes.Items[i].SubItems[0].Text == nudNodeId.Value.ToString())
                {
                    name = lvNodes.Items[i].SubItems[1].Text;
                    use = true;
                }
            // Вершина не найдена
            if (!use)
                return;

            // Пробуем найти перевод в таблице
            use = false;
            for (int i = 0; i < lvCrossSin.Items.Count; i++)
            {
                if (lvCrossSin.Items[i].SubItems[0].Text == name && lvCrossSin.Items[i].SubItems[1].Text == nudNodeId.Value.ToString())
                    for (int j = 0; j < lvSinonim.Items.Count; j++)
                        if (lvSinonim.Items[j].SubItems[0].Text == name)
                        {
                            if (nudCrossOne.Value > Convert.ToInt32(lvSinonim.Items[j].SubItems[1].Text))
                            {
                                lvCrossSin.Items[i].SubItems[2].Text = lvSinonim.Items[j].SubItems[1].Text;
                                lvCrossSin.Items[i].SubItems[3].Text = lvSinonim.Items[j].SubItems[2].Text;
                            }
                            else
                            {
                                lvCrossSin.Items[i].SubItems[2].Text = nudCrossOne.Value.ToString();
                                // ПОТЕНЦИАЛЬНО ОПАСНОЕ МЕСТО!!!!!!!! БОЙСЯ!!!!!
                                string sinonims = "";
                                for (int k = 0; k < nudCrossOne.Value; k++)
                                    if (k != nudCrossOne.Value - 1)
                                        sinonims += lvSinonim.Items[j].SubItems[2].Text.Split(',')[k].Trim() + ", ";
                                    else 
                                        sinonims += lvSinonim.Items[j].SubItems[2].Text.Split(',')[k].Trim();
                                lvCrossSin.Items[i].SubItems[3].Text = sinonims;
                            }
                            use = true;
                        }
            }

            if (!use)
            {
                ListViewItem item = new ListViewItem(name);
                item.SubItems.Add(nudNodeId.Value.ToString());
                for (int i = 0; i < lvSinonim.Items.Count; i++)
                    if (lvSinonim.Items[i].SubItems[0].Text == name)
                    {
                        if (nudCrossOne.Value > Convert.ToInt32(lvSinonim.Items[i].SubItems[1].Text))
                        {
                            item.SubItems.Add(lvSinonim.Items[i].SubItems[1].Text);
                            item.SubItems.Add(lvSinonim.Items[i].SubItems[2].Text);
                        }
                        else
                        {
                            item.SubItems.Add(nudCrossOne.Value.ToString());
                            // ПОТЕНЦИАЛЬНО ОПАСНОЕ МЕСТО!!!!!!!! БОЙСЯ!!!!!
                            string sinonims = "";
                            for (int k = 0; k < nudCrossOne.Value; k++)
                                if (k != nudCrossOne.Value - 1)
                                    sinonims += lvSinonim.Items[i].SubItems[2].Text.Split(',')[k].Trim() + ", ";
                                else
                                    sinonims += lvSinonim.Items[i].SubItems[2].Text.Split(',')[k].Trim();
                            item.SubItems.Add(sinonims);
                        }
                    }
                
                lvCrossSin.Items.Add(item);
            }
        }

        private void bUpdateOntSin_Click(object sender, EventArgs e)
        {
            int maxIndex = 0;
            for (int i = 0; i < lvNodes.Items.Count; i++)
                if (Convert.ToInt32(lvNodes.Items[i].SubItems[0].Text) > maxIndex)
                    maxIndex = Convert.ToInt32(lvNodes.Items[i].SubItems[0].Text);
            for (int i = 0; i < lvRibs.Items.Count; i++)
                if (Convert.ToInt32(lvRibs.Items[i].SubItems[1].Text) > maxIndex)
                    maxIndex = Convert.ToInt32(lvRibs.Items[i].SubItems[1].Text);
            maxIndex++;

            // Добавляем вершины и отношения
            for (int i = 0; i < lvCrossSin.Items.Count; i++)
            {
                for (int j = 0; j < Convert.ToInt32(lvCrossSin.Items[i].SubItems[2].Text); j++)
                {
                    ListViewItem item = new ListViewItem(maxIndex.ToString());
                    item.SubItems.Add(lvCrossSin.Items[i].SubItems[3].Text.Split(',')[j].Trim());
                    item.SubItems.Add("");
                    item.SubItems.Add("0");
                    item.SubItems.Add("0");
                    lvNodes.Items.Add(item);

                    ListViewItem item2 = new ListViewItem(lvCrossSin.Items[i].SubItems[1].Text);
                    item2.SubItems.Add((maxIndex + 1).ToString());
                    item2.SubItems.Add("synonym");
                    item2.SubItems.Add("");
                    item2.SubItems.Add(maxIndex.ToString());
                    lvRibs.Items.Add(item2);

                    maxIndex += 2;
                }
            }
        }

        private void bSaveOnt_Click(object sender, EventArgs e)
        {
            int maxIndex = 0;
            for (int i = 0; i < lvNodes.Items.Count; i++)
                if (Convert.ToInt32(lvNodes.Items[i].SubItems[0].Text) > maxIndex)
                    maxIndex = Convert.ToInt32(lvNodes.Items[i].SubItems[0].Text);
            for (int i = 0; i < lvRibs.Items.Count; i++)
                if (Convert.ToInt32(lvRibs.Items[i].SubItems[1].Text) > maxIndex)
                    maxIndex = Convert.ToInt32(lvRibs.Items[i].SubItems[1].Text);
            maxIndex++;

            string result = "{\n    \"last_id\": \"" + maxIndex + "\",\n    \"namespaces\": {\n        " +
            "\"\": \"http://movs.psu.ru/~ipostanogov/0.owl#\",\n        \"ontolis\": \"http://knova.ru/ontolis#\",\n        " +
                "\"default\": \"http://knova.ru/user/1604673347699\",\n        \"ontolis-avis\": \"http://knova.ru/ontolis-avis\",\n        " +
                "\"owl\": \"http://www.w3.org/2002/07/owl\",\n        \"rdf\": \"http://www.w3.org/1999/02/22-rdf-syntax-ns\",\n        " +
            "\"reply-converters\": \"http://knova.ru/reply/converter#\",\n        \"rdfs\": \"http://www.w3.org/2000/01/rdf-schema\",\n        " +
            "\"xsd\": \"http://www.w3.org/2001/XMLSchema\"\n    },\n    \"nodes\": [";

            for (int i = 0; i < lvNodes.Items.Count; i++)
            {
                if (i != 0)
                    result += ",";
                var el = lvNodes.Items[i].SubItems;
                result += "\n        {\n            \"attributes\": {\n            },\n            \"id\": \"" + el[0].Text + "\",\n            " +
                    "\"name\": \"" + el[1].Text + "\",\n";
                if (el[2].Text != "")
                    result += "            \"namespace\": \"" + el[2].Text + "\",\n";
                else
                    result += "            \"namespace\": \"http://knova.ru/user/1604673347699\",\n";
                result += "            \"position_x\": " + el[3].Text + ",\n            \"position_y\": " + el[4].Text + "\n        }";
            }
            result += "\n    ],\n    \"relations\": [";
            for (int i = 0; i < lvRibs.Items.Count; i++)
            {
                if (i != 0)
                    result += ",";
                var el = lvRibs.Items[i].SubItems;
                result += "\n        {\n            \"attributes\": {\n            },\n            \"destination_node_id\": \"" +
                    el[0].Text + "\",\n            \"id\": \"" + el[1].Text + "\",\n            \"name\": \"" + el[2].Text + "\",\n";
                if (el[3].Text != "")
                    result += "            \"namespace\": \"" + el[3].Text + "\",\n";
                else
                    result += "            \"namespace\": \"http://knova.ru/user/1604673347699\",\n";
                result += "            \"source_node_id\": \"" + el[4].Text + "\"\n        }";
            }

            result += "\n    ],\n    \"visualize_ont_path\": \"\"\n}";


            using (SaveFileDialog saveDialog = new SaveFileDialog())
            {
                saveDialog.Filter = "|*.ont";
                if (saveDialog.ShowDialog(this) == DialogResult.Cancel)
                    return;
                string filename = saveDialog.FileName;
                File.WriteAllText(filename, result);
            }
        }

        private void InteractionWithReply_Resize(object sender, EventArgs e)
        {
            lRibs.Location = new Point(this.Width / 2, 310);
            lvRibs.Location = new Point(this.Width / 2, 330);
            lvRibs.Width = this.Width / 2 - 20;
            lNodes.Location = new Point(0, 310);
            lvNodes.Location = new Point(0, 330);
            lvNodes.Width = this.Width / 2 - 20;
            for (int i = 0; i < lvNodes.Columns.Count; i++)
                lvNodes.Columns[i].Width = lvNodes.Width / lvNodes.Columns.Count;
            for (int i = 0; i < lvRibs.Columns.Count; i++)
                lvRibs.Columns[i].Width = lvRibs.Width / lvRibs.Columns.Count;
            tpChoiseOnt_Resize(sender, e);
            tpTranslateV_Resize(sender, e);
            tpSinonim_Resize(sender, e);
        }

        private void tpChoiseOnt_Resize(object sender, EventArgs e)
        {
            bCreateOnt.Location = new Point(20, 155);
            bCreateOnt.Width = this.Width / 2 - 50;
            bChoiseDir.Location = new Point(20, 100);
            bChoiseDir.Width = this.Width / 4 - 30;
            tbDirName.Location = new Point(this.Width / 4, 108);
            tbDirName.Width = this.Width / 4 - 30;
            bSaveStringCon.Location = new Point(20, 48);
            bSaveStringCon.Width = this.Width / 4 - 30;
            cbStringCon.Location = new Point(this.Width / 4, 54);
            cbStringCon.Width = this.Width / 4 - 30;
            lStringCon.Location = new Point(this.Width / 5, 14);
            lStringCon.Width = this.Width * 2 / 5 - 30;
            bLoadOnt.Location = new Point(this.Width / 2, 155);
            bLoadOnt.Width = this.Width / 2 - 40;
            lReply.Location = new Point(this.Width / 100, 190);
            rtbComment.Location = new Point(this.Width / 100, 210);
            rtbComment.Width = this.Width * 96 / 100;
        }

        private void tpTranslateV_Resize(object sender, EventArgs e)
        {
            bLoadDictionary.Location = new Point(this.Width / 16, 20);
            bLoadDictionary.Width = this.Width / 4;
            bCross.Location = new Point(this.Width * 6 / 16, 20);
            bCross.Width = this.Width / 4;
            bUpdateOntTr.Location = new Point(this.Width * 11 / 16, 20);
            bUpdateOntTr.Width = this.Width / 4;
            lDictionary.Location = new Point(this.Width / 100, 78);
            lCross.Location = new Point(this.Width / 100, 78);
            lvDictionary.Location = new Point(this.Width / 100, 98);
            lvDictionary.Width = this.Width * 15 / 50;
            lvCross.Location = new Point(this.Width / 100 + lvDictionary.Width + 20, 98);
            lvCross.Width = this.Width * 3 / 5;

            for (int i = 0; i < lvDictionary.Columns.Count; i++)
                lvDictionary.Columns[i].Width = lvDictionary.Width / lvDictionary.Columns.Count;
            for (int i = 0; i < lvCross.Columns.Count; i++)
                lvCross.Columns[i].Width = lvCross.Width / lvCross.Columns.Count;
        }

        private void tpSinonim_Resize(object sender, EventArgs e)
        {
            bLoadSinonim.Location = new Point(this.Width / 28, 76);
            bLoadSinonim.Width = this.Width * 13 / 50;
            lLoadSinonim.Location = new Point(this.Width / 100, 135);
            lvSinonim.Location = new Point(this.Width / 100, 160);
            lvSinonim.Width = this.Width * 15 / 50;

            bCrossAllNode.Location = new Point(this.Width * 16 / 50, 9);
            bCrossAllNode.Width = Width * 29 / 50;
            nudCrossAll.Location = new Point(this.Width * 91 / 100, 9);
            nudCrossAll.Width = Width / 15;

            lNodeId.Location = new Point(Width * 16 / 50, 58);
            nudNodeId.Location = new Point(Width * 22 / 50, 58);
            nudNodeId.Width = Width / 15;
            bCrossOneNode.Location = new Point(Width * 39 / 75, 58);
            bCrossOneNode.Width = Width / 7;
            nudCrossOne.Location = new Point(Width * 360 / 525, 58);
            nudCrossOne.Width = Width / 15;

            bUpdateOntSin.Location = new Point(Width * 16 / 50, 88);
            bUpdateOntSin.Width = Width * 33 / 50;

            lCrossSinonom.Location = new Point(Width * 16 / 50, 135);
            lvCrossSin.Location = new Point(this.Width * 16 / 50, 160);
            lvCrossSin.Width = this.Width * 33 / 50;
            for (int i = 0; i < lvCrossSin.Columns.Count; i++)
                lvCrossSin.Columns[i].Width = lvCrossSin.Width / lvCrossSin.Columns.Count;
            for (int i = 0; i < lvSinonim.Columns.Count; i++)
                lvSinonim.Columns[i].Width = lvSinonim.Width / lvSinonim.Columns.Count;
        }

        private void choiseDir_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FBD = new FolderBrowserDialog();
            FBD.ShowNewFolderButton = false;
            if (FBD.ShowDialog() == DialogResult.OK)
                tbDirName.Text = FBD.SelectedPath;
        }

        private void bSaveStringCon_Click(object sender, EventArgs e)
        {
            using (StreamWriter writer = File.AppendText("config.txt"))
                writer.WriteLine(cbStringCon.Text);
            cbStringCon.Items.Add(cbStringCon.Text);
        }

        private void bDeleteNodesID_Click(object sender, EventArgs e)
        {
            for (int i = lvNodes.Items.Count - 1; i > -1; i--)
            {
                string node = lvNodes.Items[i].SubItems[1].Text.ToLower();
                if (node.Length > 1 && (node.Substring(0, 2) == "id" || node.Substring(node.Length - 2, 2) == "id"))
                {
                    string id = lvNodes.Items[i].SubItems[0].Text;
                    for (int j = lvRibs.Items.Count - 1; j > -1; j--)
                        if (lvRibs.Items[j].SubItems[0].Text == id || lvRibs.Items[j].SubItems[4].Text == id)
                            lvRibs.Items.RemoveAt(j);
                    lvNodes.Items.RemoveAt(i);
                }
            }
        }

        private void bReplace__Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lvNodes.Items.Count; i++)
                lvNodes.Items[i].SubItems[1].Text = lvNodes.Items[i].SubItems[1].Text.Replace("_", " ");
        }
    }
}
