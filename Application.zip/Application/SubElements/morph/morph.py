import pymorphy2
morph = pymorphy2.MorphAnalyzer()
fin = open('read.txt', 'r', encoding='utf-8')
list_data = fin.read().split('/')
fin.close()
fout = open('write.txt', 'w')
# Усложнение сделано для покрытия случая с переводом и синонимами
for words in list_data:
    list_word = words.split('&')
    if len(list_word) > 1:
        for word in list_word:
            res = morph.parse(word)
            fout.write(str(res[0]) + '&')
    else:
        res = morph.parse(words)
        fout.write(str(res[0]))
    fout.write('\n')
fout.close()